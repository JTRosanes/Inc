-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2022 at 05:14 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinefoodphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `code` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `username`, `password`, `email`, `code`, `date`) VALUES
(1, 'admin', 'CAC29D7A34687EB14B37068EE4708E7B', 'admin@mail.com', '', '2022-05-27 13:21:52');

-- --------------------------------------------------------

--
-- Table structure for table `dishes`
--

CREATE TABLE `dishes` (
  `d_id` int(222) NOT NULL,
  `rs_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `slogan` varchar(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `img` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dishes`
--

INSERT INTO `dishes` (`d_id`, `rs_id`, `title`, `slogan`, `price`, `img`) VALUES
(1, 0, 'POCO M4', '.43-inch FHD+ AMOLED display with a 90Hz refresh rate, 64MP + 8MP + 2MP triple rear cameras, and a 16MP selfie camera', '12000.00', '635216d47bc10.jpg'),
(2, 1, 'OPPO Find X', '42-inch screen, octa core processor and Android 8.1 Oreo operating system', '30000.00', '63521fdfa23cf.jpg'),
(3, 4, 'POCO X3', '9.4mm thickness Android 11, up to 12, MIUI 13 for POCO 128GB/256GB storage, microSDXC 13% 7,913,522 hits', '15990.00', '63521552df541.jpg'),
(4, 4, 'POCO M4 Pro 5G', 'Dimensity 810 5G 90Hz refresh rate 33W Pro fast charging', '36000.00', '635220bd58196.jpg'),
(5, 2, 'iPhone11', ' 8.3mm thickness iOS 13, up to iOS 16.0.3. 64GB/128GB/256GB storage, no card slot; 32% 13,534,502 hits; 619 Become a fan', '25000.00', '635218b8772e0.jpg'),
(6, 2, 'iPhone12', 'CPU, Hexa-core (2x3.1 GHz Firestorm + 4x1.8 GHz Icestorm) ; GPU, Apple GPU (4-core graphics) ; Memory, Card slot ; Internal, 64GB 4GB RAM, 128GB ... Internal: 64GB 4GB RAM, 128GB 4GB RAM, 2... Battery life: Endurance ratin', '35000.00', '6352180f17d77.jpg'),
(7, 2, 'iPhone X', ' 5.8? display, Apple A11 Bionic chipset, Dual: 12 MP (f/1.8, 28mm, 1.22µm) + 12 MP primary camera, ... Body: Dimensions', '30000.00', '635219956c3be.jpg'),
(8, 2, 'iPhone 6', ' Features 4.7? display, Apple A8 chipset, 8 MP primary camera, 1.2 MP front camera, 1810 mAh battery, ... Network: Technology', '7000.00', '63521a511395d.jpg'),
(9, 3, 'Samsung Galaxy S6 edge', ' Samsung Galaxy S6 edge MORE PICTURES Released 2015, April 132g, 7mm thickness Android 5.0.2, up to 7.0, TouchWiz UI 32GB/64GB/128GB storage, no card slot', '27000.00', '63521d667f1d7.jpg'),
(10, 3, ' Galaxy A13 ;', 'Resolution, 1080 x 2408 pixels, 20:9 ratio (~400 ppi density) ; Protection, Corning Gorilla Glass 5 ; Platform, OS ; Chipset, Exynos 850 (8nm).', '25000.00', '63521cb882499.jpg'),
(11, 3, 'Samsung Galaxy A12', 'leased 2020, December 21 205g, 8.9mm thickness Android 10, up to Android 11, One UI 3.1 32GB/64GB/128GB storage, microSDXC', '15000.00', '63521bcde2565.jpg'),
(12, 3, 'Samsung Galaxy S10', 'amsung Galaxy S10 Android smartphone. Announced Feb 2019. Features 6.1? display, Exynos 9820 chipset, 3400 mAh battery, 512 GB storage, 8 GB RAM', '20000.00', '63521b46cf9ec.jpg'),
(13, 4, 'POCO F4', 'Snapdragon 870 platform, AMOLED screen with 120Hz refresh rate, and powerful configuration such as 64MP triple mirrors. The Hong Kong version of 8GB RAM + 256GB RO', '31000.00', '63521497197e9.jpg'),
(14, 4, 'Poco X3 GT', ' 5G smartphone that features a 6.6-inch FHD+ display with a 120Hz screen refresh rate, Gorilla Glass Victus scratch protection, 16MP selfie camera, and 64MP + 8MP + 2MP triple rear cameras . It runs on a MediaTek Dimensity', '19000.00', '635213fc25666.jpg'),
(15, 4, 'POCO F3', '8 GB RAM / 256 GB internal storage, Predator Black, Gunmetal Silver color, 64 MP Triple rear camera and 16 MP selfie camera, Processor MediaTek Dimensity 1200 5G, OS Android 11, Battery Capacity 5065mAh, Display 6.67-inch.', '19270.00', '63521294d01af.jpg'),
(16, 4, 'Poco F1', 'OS	Android 9.0 SIM	Hybrid Dual SIM, Singl SIM, Nano-SIM Front Camera	20 MP Main Camera	12MP + 5MP + 2MP Display Size	6.18 Inches Battery	4000 mAh', '16990.00', '635212d92f4bf.jpg'),
(17, 1, 'OPPO Reno5 5G', 'AI video enhancement: Super dynamic night scene + Live HDR video double video 65W SuperVOOC Super Flash Charge 2.0 Qualcomm® Snapdragon™ 765G 5G Chip 90Hz screen refresh rate', '16990.00', '63521f4d427ee.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `remark`
--

CREATE TABLE `remark` (
  `id` int(11) NOT NULL,
  `frm_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `remark` mediumtext NOT NULL,
  `remarkDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remark`
--

INSERT INTO `remark` (`id`, `frm_id`, `status`, `remark`, `remarkDate`) VALUES
(1, 2, 'in process', 'none', '2022-05-01 05:17:49'),
(2, 3, 'in process', 'none', '2022-05-27 11:01:30'),
(3, 2, 'closed', 'thank you for your order!', '2022-05-27 11:11:41'),
(4, 3, 'closed', 'none', '2022-05-27 11:42:35'),
(5, 4, 'in process', 'none', '2022-05-27 11:42:55'),
(6, 1, 'rejected', 'none', '2022-05-27 11:43:26'),
(7, 7, 'in process', 'none', '2022-05-27 13:03:24'),
(8, 8, 'in process', 'none', '2022-05-27 13:03:38'),
(9, 9, 'rejected', 'thank you', '2022-05-27 13:03:53'),
(10, 7, 'closed', 'thank you for your ordering with us', '2022-05-27 13:04:33'),
(11, 8, 'closed', 'thanks ', '2022-05-27 13:05:24'),
(12, 5, 'closed', 'none', '2022-05-27 13:18:03');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `rs_id` int(222) NOT NULL,
  `c_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `url` varchar(222) NOT NULL,
  `o_hr` varchar(222) NOT NULL,
  `c_hr` varchar(222) NOT NULL,
  `o_days` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `image` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`rs_id`, `c_id`, `title`, `email`, `phone`, `url`, `o_hr`, `c_hr`, `o_days`, `address`, `image`, `date`) VALUES
(1, 1, 'Oppo', 'nathanjofromyt@gmail.com', '09568659662', 'www.nathanjo.com', '6am', '8pm', '24hr-x7', 'Santa,Cruz Libon Albay', '6352079a15fe2.jpg', '2022-10-21 02:44:42'),
(2, 2, 'iPhone', 'nathanjofromyt@gmail.com', '09568659662', 'www.nathanjo.com', '6am', '8pm', '24hr-x7', '  Santa,Cruz Libon Albay  ', '635209688b393.jpg', '2022-10-21 02:52:24'),
(3, 3, 'Samsung', 'nathanjofromyt@gmail.com', '09568659662', 'www.nathanjo.com', '6am', '8pm', '24hr-x7', ' Santa,Cruz Libon Albay ', '635206c85b7c4.jpg', '2022-10-21 02:41:12'),
(4, 4, 'POCO', 'nathanjofromyt@gmail.com', '09568659662', 'www.nathanjo.com', '6am', '8pm', '24hr-x7', '  Santa,Cruz Libon Albay  ', '6352089d4be22.jpg', '2022-10-21 02:49:01');

-- --------------------------------------------------------

--
-- Table structure for table `res_category`
--

CREATE TABLE `res_category` (
  `c_id` int(222) NOT NULL,
  `c_name` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `res_category`
--

INSERT INTO `res_category` (`c_id`, `c_name`, `date`) VALUES
(1, 'Oppo', '2022-10-21 02:38:34'),
(2, 'iPhone', '2022-10-21 02:53:13'),
(3, 'Samsung', '2022-10-21 02:37:45'),
(4, 'POCO', '2022-10-21 02:37:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `f_name` varchar(222) NOT NULL,
  `l_name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `status` int(222) NOT NULL DEFAULT 1,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `username`, `f_name`, `l_name`, `email`, `phone`, `password`, `address`, `status`, `date`) VALUES
(1, 'eric', 'Eric', 'Lopez', 'eric@mail.com', '1458965547', 'a32de55ffd7a9c4101a0c5c8788b38ed', '87 Armbrester Drive', 1, '2022-05-27 08:40:36'),
(2, 'harry', 'Harry', 'Holt', 'harryh@mail.com', '3578545458', 'bc28715006af20d0e961afd053a984d9', '33 Stadium Drive', 1, '2022-05-27 08:41:07'),
(3, 'james', 'James', 'Duncan', 'james@mail.com', '0258545696', '58b2318af54435138065ee13dd8bea16', '67 Hiney Road', 1, '2022-05-27 08:41:37'),
(4, 'christine', 'Christine', 'Moore', 'christine@mail.com', '7412580010', '5f4dcc3b5aa765d61d8327deb882cf99', '114 Test Address', 1, '2022-05-01 05:14:42'),
(5, 'scott', 'Scott', 'Miller', 'scott@mail.com', '7896547850', '5f4dcc3b5aa765d61d8327deb882cf99', '63 Charack Road', 1, '2022-05-27 10:53:51'),
(6, 'Mark', 'JOnathan', 'Acio', 'liamoore@mail.com', '7896969696', 'test123', '122 Bleck Street', 1, '2022-10-21 01:09:19'),
(7, 'pam', 'Pam', 'Pam', 'jonathantorres.rosanes@bicol-u.edu.ph', '09568659662', 'fd4c5c23c4e6cd487330a020bf1f5a31', 'sta cruz', 1, '2022-10-21 14:57:10');

-- --------------------------------------------------------

--
-- Table structure for table `users_orders`
--

CREATE TABLE `users_orders` (
  `o_id` int(222) NOT NULL,
  `u_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `quantity` int(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` varchar(222) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_orders`
--

INSERT INTO `users_orders` (`o_id`, `u_id`, `title`, `quantity`, `price`, `status`, `date`) VALUES
(10, 7, 'POCO M4', 1, '12000.00', NULL, '2022-10-21 15:02:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `dishes`
--
ALTER TABLE `dishes`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `remark`
--
ALTER TABLE `remark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `res_category`
--
ALTER TABLE `res_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `users_orders`
--
ALTER TABLE `users_orders`
  ADD PRIMARY KEY (`o_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dishes`
--
ALTER TABLE `dishes`
  MODIFY `d_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `remark`
--
ALTER TABLE `remark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `rs_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `res_category`
--
ALTER TABLE `res_category`
  MODIFY `c_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users_orders`
--
ALTER TABLE `users_orders`
  MODIFY `o_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
